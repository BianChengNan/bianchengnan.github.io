// WaitDllUnloadExe.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"

int _tmain(int argc, _TCHAR* argv[])
{
	HMODULE module = LoadLibraryA(".\\DllUnload.dll");

	Sleep(5000);

	FreeLibrary(module);

	return 0;
}

